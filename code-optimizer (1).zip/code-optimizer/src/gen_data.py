"""Generate a labelled bug dataset for the ML model.

Idea (weak supervision): take CLEAN programs from templates, INJECT a known bug with a mutation,
and label the result with the rule-based checker (src/checker.py). So the ML model learns to
predict bug categories straight from the code text.

    python -m src.gen_data --n 6000          # writes data/ml_train.jsonl, ml_val.jsonl, ml_test.jsonl
Test set = templates the model never saw in training (a fair generalisation test).
"""
import argparse, ast, builtins, json, keyword, os, random, re, sysconfig, zlib, warnings
from collections import Counter
from src.checker import check

LABELS = ["syntax", "variable", "loop", "function", "type", "logic"]
CODE2CAT = {}
for cat, codes in {
    "syntax": ["E-SYNTAX", "E-BRACKET", "E-COLON"],
    "variable": ["E-UNDEFINED", "E-UNBOUND", "W-MAYBE-UNDEFINED"],
    "loop": ["E-FOR-LEN", "E-FOR-NUMBER", "E-INFINITE-LOOP", "W-LOOP-NOCHANGE", "W-OFF-BY-ONE",
             "W-MODIFY-WHILE-ITERATING", "W-LOOPVAR-REUSE", "E-RANGE-ARGS", "E-RANGE-FLOAT",
             "E-RANGE-STEP", "W-EMPTY-RANGE"],
    "function": ["E-MISSING-ARGS", "E-TOO-MANY-ARGS", "E-UNKNOWN-KWARG", "E-DUP-ARG", "W-MUTABLE-DEFAULT",
                 "W-MISSING-RETURN", "W-NO-BASE-CASE", "E-NO-SELF", "E-APPEND-ARGS"],
    "type": ["E-INPUT-STR", "E-STR-PLUS-NUM", "E-DIV-ZERO", "E-INDEX-LEN"],
    "logic": ["W-NONE-COMPARE", "W-BOOL-COMPARE", "W-OR-CONSTANT", "W-IS-LITERAL", "W-NONE-RESULT",
              "W-UNREACHABLE", "W-CONST-CONDITION"],
}.items():
    for c in codes:
        CODE2CAT[c] = cat


def categories(code):
    return sorted({CODE2CAT[i.code] for i in check(code).issues if i.code in CODE2CAT})


# ------------------------------------------------------------------ real code: clean functions from the Python stdlib
_STD = {}


def stdlib_functions():
    """Small self-contained top-level functions from the stdlib that the checker finds clean.
    Returns {"train": [...], "test": [...]}; whole MODULES are held out for the test split."""
    if _STD:
        return _STD
    root = sysconfig.get_paths()["stdlib"]
    out = {"train": [], "test": []}
    for fn in sorted(os.listdir(root)):
        if not fn.endswith(".py") or fn.startswith(("test", "_")):
            continue
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                tree = ast.parse(open(os.path.join(root, fn), encoding="utf-8").read())
        except Exception:
            continue
        side = "test" if zlib.crc32(fn.encode()) % 5 == 0 else "train"
        for node in tree.body:
            if not isinstance(node, ast.FunctionDef) or node.decorator_list:
                continue
            if not (3 <= (node.end_lineno - node.lineno + 1) <= 30):
                continue
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(getattr(node.body[0], "value", None), ast.Constant) \
                    and isinstance(node.body[0].value.value, str):
                node.body = node.body[1:] or [ast.Pass()]
            if any(isinstance(n, (ast.Yield, ast.YieldFrom, ast.Global, ast.Nonlocal, ast.Await)) for n in ast.walk(node)):
                continue
            code = ast.unparse(node) + "\n"
            if len(code) < 400 and not categories(code):
                out[side].append(code)
    _STD.update(out)
    return _STD


# ------------------------------------------------------------------ clean templates
TEMPLATES = [
"def {f}({L}):\n    {acc} = 0\n    for {e} in {L}:\n        {acc} += {e}\n    return {acc}\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}({L}):\n    best = {L}[0]\n    for {e} in {L}:\n        if {e} > best:\n            best = {e}\n    return best\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}({L}):\n    {acc} = 0\n    for i in range(len({L})):\n        if {L}[i] % 2 == 0:\n            {acc} += 1\n    return {acc}\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}(n):\n    while n > 0:\n        print(n)\n        n -= 1\n    return n\n\n{f}({a})\n",
"age = int(input(\"Enter age: \"))\nif age >= {a}:\n    print(\"adult\")\nelse:\n    print(\"minor\")\n",
"def {f}(n):\n    if n <= 1:\n        return 1\n    return n * {f}(n - 1)\n\nprint({f}({a}))\n",
"def {f}({L}):\n    if len({L}) == 0:\n        return 0\n    total = sum({L})\n    return total / len({L})\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}(words):\n    out = []\n    for w in words:\n        out.append(w.upper())\n    return \" \".join(out)\n\nprint({f}([\"a\", \"b\"]))\n",
"class {C}:\n    def __init__(self, {p}):\n        self.{p} = {p}\n\n    def show(self):\n        return self.{p}\n\nobj = {C}({a})\nprint(obj.show())\n",
"def {f}(text):\n    counts = {{}}\n    for ch in text:\n        if ch in counts:\n            counts[ch] += 1\n        else:\n            counts[ch] = 1\n    return counts\n\nprint({f}(\"hello\"))\n",
"for i in range(1, {a}):\n    for j in range(1, {b}):\n        print(i * j)\n",
"def {f}({L}, target):\n    for {e} in {L}:\n        if {e} == target:\n            return True\n    return False\n\nprint({f}([{a}, {b}], {c}))\n",
"def {f}({L}):\n    result = []\n    for {e} in {L}:\n        if {e} > 0:\n            result.append({e})\n    return result\n\nprint({f}([{a}, -{b}, {c}]))\n",
"def {f}(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n\nprint({f}({a}))\n",
"def {f}(s):\n    try:\n        return int(s)\n    except ValueError:\n        return None\n\nprint({f}(\"{a}\"))\n",
# templates 15-19 and 27-31 are held out (used only for the unseen-template test set)
"def {f}(score):\n    if score >= 90:\n        grade = \"A\"\n    elif score >= 60:\n        grade = \"B\"\n    else:\n        grade = \"C\"\n    return grade\n\nprint({f}({a}))\n",
"def add(a, b):\n    return a + b\n\ndef {f}({L}):\n    total = 0\n    for {e} in {L}:\n        total = add(total, {e})\n    return total\n\nprint({f}([{a}, {b}]))\n",
"def {f}({L}):\n    i = 0\n    {acc} = 0\n    while i < len({L}):\n        {acc} += {L}[i]\n        i += 1\n    return {acc}\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}(s):\n    s = s.lower()\n    return s == s[::-1]\n\nprint({f}(\"Level\"))\n",
"c = float(input(\"Celsius: \"))\nfah = c * 9 / 5 + 32\nprint(fah)\n",
"def {f}({L}):\n    s = 0\n    n = 0\n    for {e} in {L}:\n        s += {e}\n        n += 1\n    if n == 0:\n        return 0\n    return s / n\n\nprint({f}([{a}, {b}]))\n",
"def {f}(text):\n    count = 0\n    for ch in text:\n        if ch in \"aeiou\":\n            count += 1\n    return count\n\nprint({f}(\"education\"))\n",
"def {f}(d, key):\n    if key in d:\n        return d[key]\n    return None\n\nprint({f}({{\"a\": {a}}}, \"a\"))\n",
"def {f}({L}):\n    lo = {L}[0]\n    hi = {L}[0]\n    for {e} in {L}:\n        if {e} < lo:\n            lo = {e}\n        if {e} > hi:\n            hi = {e}\n    return lo, hi\n\nprint({f}([{a}, {b}, {c}]))\n",
"class {C}:\n    def __init__(self):\n        self.count = 0\n\n    def add(self, n):\n        self.count += n\n        return self.count\n\nobj = {C}()\nobj.add({a})\nprint(obj.count)\n",
"for i in range(0, {a}, 2):\n    print(i)\n",
"while True:\n    line = input(\"> \")\n    if line == \"quit\":\n        break\n    print(line)\n",
"def {f}({L}):\n    return sum([{e} * {e} for {e} in {L}])\n\nprint({f}([{a}, {b}]))\n",
"def {f}(path):\n    with open(path) as fh:\n        lines = fh.readlines()\n    return len(lines)\n\nprint({f}(\"data.txt\"))\n",
"def {f}({L}):\n    n = len({L})\n    for i in range(n):\n        for j in range(n - i - 1):\n            if {L}[j] > {L}[j + 1]:\n                {L}[j], {L}[j + 1] = {L}[j + 1], {L}[j]\n    return {L}\n\nprint({f}([{a}, {b}, {c}]))\n",
"def {f}(name, greeting=\"Hello\"):\n    return greeting + \", \" + name\n\nprint({f}(\"Sam\", greeting=\"Hi\"))\n",
"temp = {a}\nwhile temp < {b} + {a}:\n    print(temp)\n    temp += 5\n",
]
TEST_IDS = [15, 16, 17, 18, 19, 27, 28, 29, 30, 31]          # never used for training
TRAIN_IDS = [i for i in range(32) if i not in TEST_IDS]

POOL = dict(
    f=["calc", "process", "compute", "run_task", "solve", "handle", "check_value", "get_result", "analyze", "summarize"],
    L=["nums", "data", "items", "values", "arr", "scores", "numbers", "readings"],
    e=["x", "n", "item", "val", "v", "num", "elem"],
    acc=["total", "count", "result", "acc", "s"],
    C=["Box", "Person", "Item", "Account", "Student"], p=["name", "size", "value", "owner", "title"])


def make_clean(tids, rng):
    """Build one program from 1-3 templates (more realistic: longer, several functions)."""
    tids = [tids] if isinstance(tids, int) else list(tids)
    used, parts = set(), []
    for tid in tids:
        d = {k: rng.choice(v) for k, v in POOL.items()}
        while d["f"] in used:
            d["f"] = rng.choice(POOL["f"]) + str(rng.randint(2, 9))
        used.add(d["f"])
        d["e"] = d["e"] if d["e"] != d["L"] else "x"
        d.update(a=rng.randint(2, 40), b=rng.randint(2, 40), c=rng.randint(2, 40))
        parts.append(TEMPLATES[tid].format(**d))
    code = "\n".join(parts)
    if rng.random() < 0.3:
        code = rng.choice(["# helper script\n", "# TODO: review\n", "# main logic\n"]) + code
    return code


# ------------------------------------------------------------------ mutators (inject one bug)
SAFE = set(keyword.kwlist) | set(dir(builtins)) | {"self", "append", "upper", "lower", "join", "remove", "sort", "ValueError"}


def _lines(code):
    return code.split("\n")


def m_drop_colon(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if l.rstrip().endswith(":")]
    if not idx: return None
    i = rng.choice(idx); ls[i] = ls[i].rstrip()[:-1]; return "\n".join(ls)


def m_drop_paren(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if ")" in l]
    if not idx: return None
    i = rng.choice(idx); k = ls[i].rfind(")"); ls[i] = ls[i][:k] + ls[i][k + 1:]; return "\n".join(ls)


def m_drop_quote(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if '"' in l]
    if not idx: return None
    i = rng.choice(idx); k = ls[i].rfind('"'); ls[i] = ls[i][:k] + ls[i][k + 1:]; return "\n".join(ls)


def m_bad_indent(code, rng):
    ls = _lines(code)
    idx = [i for i in range(len(ls) - 1) if ls[i].rstrip().endswith(":") and ls[i + 1].startswith(" ")]
    if not idx: return None
    i = rng.choice(idx); ls[i + 1] = ls[i + 1].lstrip(); return "\n".join(ls)


def m_typo(code, rng):
    cnt = Counter(re.findall(r"[A-Za-z_]\w*", code))
    c = [w for w, k in cnt.items() if k >= 2 and len(w) >= 3 and w not in SAFE]
    if not c: return None
    w = rng.choice(sorted(c))
    ms = list(re.finditer(rf"\b{w}\b", code))
    m = ms[-1]
    typo = rng.choice([w + "s", w[:-1], w[0] + w[2] + w[1] + w[3:], w + "_1"])
    return code[:m.start()] + typo + code[m.end():]


def m_drop_init(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if re.match(r"^\s+\w+ = (0|\[\]|\{\})$", l)]
    if not idx: return None
    del ls[rng.choice(idx)]; return "\n".join(ls)


def m_range_plus(code, rng):
    n = re.sub(r"range\(len\((\w+)\)\)", r"range(len(\1) + 1)", code, count=1)
    return n if n != code else None


def m_for_len(code, rng):
    n = re.sub(r"in range\(len\((\w+)\)\)", r"in len(\1)", code, count=1)
    return n if n != code else None


def m_drop_incr(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if re.match(r"^\s+\w+ [+-]= 1$", l)]
    if not idx or "while" not in code: return None
    del ls[rng.choice(idx)]; return "\n".join(ls)


def m_while_true(code, rng):
    n = re.sub(r"while [^\n]+:", "while True:", code, count=1)
    return n if n != code else None


def m_modify_iter(code, rng):
    m = re.search(r"^( *)for (\w+) in (\w+):\n", code, re.M)
    if not m: return None
    ins = f"{m.group(1)}    {m.group(3)}.remove({m.group(2)})\n"
    return code[:m.end()] + ins + code[m.end():]


def m_loopvar(code, rng):
    if "for i in" in code and "for j in" in code:
        return code.replace("for j in", "for i in", 1)
    return None


def m_drop_return(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if re.match(r"^    return ", l)]
    if len(idx) < 1: return None
    del ls[idx[-1]]; return "\n".join(ls)


def m_arity(code, rng):
    names = re.findall(r"^def (\w+)\(", code, re.M)
    rng.shuffle(names)
    for nm in names:
        pat = re.compile(rf"(?<!def )\b{nm}\(([^()]*)\)")
        m = pat.search(code)
        if m:
            if rng.random() < 0.5:
                new = f"{nm}({m.group(1)}{', ' if m.group(1) else ''}99)"
            else:
                new = f"{nm}()"
            return code[:m.start()] + new + code[m.end():]
    return None


def m_mutable_default(code, rng):
    n = re.sub(r"^def (\w+)\(([^)]*)\):", lambda m: f"def {m.group(1)}({m.group(2)}{', ' if m.group(2) else ''}memo=[]):",
               code, count=1, flags=re.M)
    return n if n != code else None


def m_no_base(code, rng):
    n = re.sub(r"^    if [^\n]*:\n        return [^\n]*\n", "", code, count=1, flags=re.M)
    return n if n != code else None


def m_no_self(code, rng):
    n = re.sub(r"def (?!__init__)(\w+)\(self\)", r"def \1()", code, count=1)
    return n if n != code else None


def m_input_nocast(code, rng):
    n = re.sub(r"(?:int|float)\(input\((.*?)\)\)", r"input(\1)", code, count=1)
    return n if n != code else None


def m_str_plus_num(code, rng):
    return code.rstrip("\n") + f'\nprint("Value: " + {rng.randint(1, 9)})\n'


def m_div_zero(code, rng):
    n = re.sub(r"/ len\(\w+\)", "/ 0", code, count=1)
    return n if n != code else code.rstrip("\n") + f"\nprint({rng.randint(1, 9)} / 0)\n"


def m_index_len(code, rng):
    n = re.sub(r"(\w+)\[0\]", r"\1[len(\1)]", code, count=1)
    return n if n != code else None


def m_eq_none(code, rng):
    n = re.sub(r"== 0", "== None", code, count=1)
    return n if n != code else None


def m_or_const(code, rng):
    n = re.sub(r"if ([^\n]+?) == (\w+):", r"if \1 == \2 or 5:", code, count=1)
    return n if n != code else None


def m_none_result(code, rng):
    return code.rstrip("\n") + "\nordered = [3, 1, 2].sort()\n"


def m_unreachable(code, rng):
    ls = _lines(code); idx = [i for i, l in enumerate(ls) if re.match(r"^ +return ", l)]
    if not idx: return None
    i = rng.choice(idx); ind = re.match(r"^ +", ls[i]).group(0)
    ls.insert(i + 1, ind + 'print("done")'); return "\n".join(ls)


def m_is_literal(code, rng):
    n = re.sub(r"== (\d+)", r"is \1", code, count=1)
    return n if n != code else None


MUTATORS = {
    "syntax": [m_drop_colon, m_drop_paren, m_drop_quote, m_bad_indent],
    "variable": [m_typo, m_drop_init],
    "loop": [m_range_plus, m_for_len, m_drop_incr, m_while_true, m_modify_iter, m_loopvar],
    "function": [m_drop_return, m_arity, m_mutable_default, m_no_base, m_no_self],
    "type": [m_input_nocast, m_str_plus_num, m_div_zero, m_index_len],
    "logic": [m_eq_none, m_or_const, m_none_result, m_unreachable, m_is_literal],
}


def make_sample(tids, rng, clean_code=None):
    code = clean_code if clean_code is not None else make_clean(tids, rng)
    if rng.random() < 0.28:                      # keep clean (verify it really is clean)
        return (code, []) if not categories(code) else None
    for _ in range(rng.choice([1, 1, 1, 2])):
        for _try in range(10):
            fn = rng.choice(MUTATORS[rng.choice(LABELS + ["loop"] * 3)])
            new = fn(code, rng)
            if new and new != code:
                code = new
                break
    labs = categories(code)
    return (code, labs) if labs else None


def build(n, seed=7, use_stdlib=True):
    rng = random.Random(seed)
    std = stdlib_functions() if use_stdlib else {"train": [], "test": []}
    seen, train_val, test = set(), [], []
    target_test = n // 5
    while len(train_val) < n or len(test) < target_test:
        want_test = len(test) < target_test and (len(train_val) >= n or rng.random() < 0.2)
        side = "test" if want_test else "train"
        from_std = use_stdlib and std[side] and rng.random() < 0.55
        if from_std:
            funcs = [rng.choice(std[side]) for _ in range(rng.choice([1, 1, 2, 3]))]
            tids, clean = [-1], "\n".join(funcs)
        else:
            pool = TEST_IDS if want_test else TRAIN_IDS
            tids, clean = [rng.choice(pool) for _ in range(rng.choice([1, 1, 2, 2, 3]))], None
        s = make_sample(tids, rng, clean)
        if not s or s[0] in seen:
            continue
        seen.add(s[0])
        (test if want_test else train_val).append(
            {"code": s[0], "labels": s[1], "templates": tids, "source": "stdlib" if from_std else "template"})
    rng.shuffle(train_val)
    k = int(0.85 * len(train_val))
    return train_val[:k], train_val[k:], test


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=6000); ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    tr, va, te = build(a.n, a.seed)
    os.makedirs("data", exist_ok=True)
    for name, rows in (("ml_train", tr), ("ml_val", va), ("ml_test", te)):
        with open(f"data/{name}.jsonl", "w") as f:
            for r in rows: f.write(json.dumps(r) + "\n")
        c = Counter(l for r in rows for l in r["labels"]); clean = sum(not r["labels"] for r in rows)
        nstd = sum(r["source"] == "stdlib" for r in rows)
        print(f"{name}: {len(rows)} samples | stdlib={nstd} | clean={clean} | " + ", ".join(f"{l}={c[l]}" for l in LABELS))


if __name__ == "__main__":
    main()
