"""Build train/val/test jsonl: validate syntax, dedupe, split 80/10/10.
    python -m src.data_prep [--extra data/extra.jsonl]
extra.jsonl lines: {"slow": "...", "fast": "..."}  (func/inputs optional; needed only for verification)"""
import argparse, ast, json, random, os
from src.sample_data import PAIRS


def ok(code):
    try:
        ast.parse(code); return True
    except SyntaxError:
        return False


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--extra"); a = ap.parse_args()
    rows = list(PAIRS)
    if a.extra:
        rows += [json.loads(l) for l in open(a.extra)]
    seen, clean = set(), []
    for r in rows:
        key = r["slow"].strip()
        if key in seen or not (ok(r["slow"]) and ok(r["fast"])):
            continue
        seen.add(key); clean.append(r)
    random.seed(42); random.shuffle(clean)
    n = len(clean); i, j = max(1, int(.8 * n)), max(2, int(.9 * n))
    os.makedirs("data", exist_ok=True)
    for name, part in (("train", clean[:i]), ("val", clean[i:j]), ("test", clean[j:])):
        with open(f"data/{name}.jsonl", "w") as f:
            for r in part: f.write(json.dumps(r) + "\n")
        print(name, len(part))
    with open("data/all.jsonl", "w") as f:   # full set with verifier info, for evaluation
        for r in clean: f.write(json.dumps(r) + "\n")


if __name__ == "__main__":
    main()
