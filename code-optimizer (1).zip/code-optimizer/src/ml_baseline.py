"""ML bug-type classifier (multi-label): TF-IDF over normalised code tokens + Logistic Regression.
Predicts which kinds of mistakes a program contains: syntax / variable / loop / function / type / logic.

    python -m src.ml_baseline --train        # trains, prints metrics, saves models/bug_clf.joblib
"""
import argparse, builtins, json, keyword, os, re
from collections import Counter
import joblib, numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support, f1_score
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import make_pipeline
from src.gen_data import LABELS

KEEP = set(keyword.kwlist) | set(dir(builtins)) | {"self", "append", "upper", "lower", "join", "remove", "sort",
                                                    "extend", "pop", "insert", "clear", "reverse", "ValueError"}
TOK = re.compile(r"[A-Za-z_]\w*|\d+\.?\d*|==|!=|<=|>=|\*\*|//|\+=|-=|\*=|/=|->|[^\s\w]")


def normalize(code: str) -> str:
    """Make the text name-independent: identifiers -> ID1 (appears once) / IDN (appears again);
    strings -> STR; most numbers -> NUM; keep indentation level and line breaks."""
    code = "\n".join(re.sub(r"#.*", "", l) for l in code.split("\n"))
    code = re.sub(r"\"[^\"\n]*\"|'[^'\n]*'", " STR ", code)
    counts = Counter(w for w in re.findall(r"[A-Za-z_]\w*", code) if w not in KEEP)
    out = []
    for line in code.split("\n"):
        if not line.strip():
            continue
        ind = (len(line) - len(line.lstrip(" \t"))) // 4
        out.append(f"IND{min(ind, 6)}")
        for t in TOK.findall(line):
            if t[0].isalpha() or t[0] == "_":
                t = t if t in KEEP or t == "STR" else ("ID1" if counts[t] == 1 else "IDN")
            elif t[0].isdigit():
                t = t if t in ("0", "1", "2") else "NUM"
            out.append(t)
        out.append("NL")
    return " ".join(out)


def load(path):
    rows = [json.loads(l) for l in open(path)]
    X = [normalize(r["code"]) for r in rows]
    Y = np.array([[int(l in r["labels"]) for l in LABELS] for r in rows])
    return rows, X, Y


def report(name, model, X, Y):
    P = model.predict(X)
    p, r, f, _ = precision_recall_fscore_support(Y, P, zero_division=0)
    print(f"\n== {name} ({len(X)} samples)")
    print(f"{'label':<10}{'precision':>10}{'recall':>9}{'f1':>7}{'support':>9}")
    for i, l in enumerate(LABELS):
        print(f"{l:<10}{p[i]:>10.2f}{r[i]:>9.2f}{f[i]:>7.2f}{int(Y[:, i].sum()):>9}")
    res = dict(micro_f1=f1_score(Y, P, average="micro", zero_division=0),
               macro_f1=f1_score(Y, P, average="macro", zero_division=0),
               exact_match=float((P == Y).all(axis=1).mean()),
               per_label={l: dict(precision=float(p[i]), recall=float(r[i]), f1=float(f[i])) for i, l in enumerate(LABELS)})
    print(f"micro-F1={res['micro_f1']:.3f}  macro-F1={res['macro_f1']:.3f}  exact-match={res['exact_match']:.3f}")
    return res


def train(out="models/bug_clf.joblib"):
    _, Xtr, Ytr = load("data/ml_train.jsonl")
    _, Xva, Yva = load("data/ml_val.jsonl")
    _, Xte, Yte = load("data/ml_test.jsonl")
    model = make_pipeline(
        TfidfVectorizer(tokenizer=str.split, token_pattern=None, lowercase=False, ngram_range=(1, 3),
                        min_df=2, sublinear_tf=True),
        OneVsRestClassifier(LogisticRegression(C=5, max_iter=3000, class_weight="balanced")))
    model.fit(Xtr, Ytr)
    results = {"validation": report("VALIDATION (seen templates / modules)", model, Xva, Yva),
               "test_unseen": report("TEST (unseen templates + unseen stdlib modules)", model, Xte, Yte)}
    rte = [json.loads(l) for l in open("data/ml_test.jsonl")]
    for src in ("template", "stdlib"):
        idx = [i for i, r in enumerate(rte) if r["source"] == src]
        if idx:
            P = model.predict([Xte[i] for i in idx])
            f = f1_score(Yte[idx], P, average="micro", zero_division=0)
            results[f"test_{src}_micro_f1"] = float(f)
            print(f"  test subset '{src}': {len(idx)} samples, micro-F1={f:.3f}")
    os.makedirs("models", exist_ok=True); os.makedirs("results", exist_ok=True)
    joblib.dump({"model": model, "labels": LABELS}, out)
    json.dump(results, open("results/ml_results.json", "w"), indent=2)
    print("\nsaved", out)


def predict(code, path="models/bug_clf.joblib"):
    """Return {label: probability} for the 6 bug categories."""
    d = joblib.load(path)
    probs = d["model"].predict_proba([normalize(code)])[0]
    return {l: float(p) for l, p in zip(d["labels"], probs)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--train", action="store_true"); a = ap.parse_args()
    if a.train:
        train()
