"""Layer 2: ML model (CodeT5). Slow code in -> fast code out."""
PREFIX = "optimize: "
BASE = "Salesforce/codet5-small"


def load(path=None):
    from transformers import AutoTokenizer, T5ForConditionalGeneration
    tok = AutoTokenizer.from_pretrained(path or BASE)
    model = T5ForConditionalGeneration.from_pretrained(path or BASE)
    model.eval()
    return tok, model


def optimize(code, tok, model, max_length=512, num_beams=5):
    import torch
    inp = tok(PREFIX + code, return_tensors="pt", truncation=True, max_length=max_length)
    with torch.no_grad():
        out = model.generate(**inp, max_length=max_length, num_beams=num_beams)
    return tok.decode(out[0], skip_special_tokens=True)
