"""Layer 3: verifier. Runs original and optimized code in a subprocess (timeout),
checks the outputs match, and measures the speedup."""
import ast, json, subprocess, sys

RUNNER = r'''
import sys, json, timeit, ast
p = json.load(sys.stdin)
ns = {}
exec(p["code"], ns)
fn = ns[p["func"]]
inputs = [eval(s) for s in p["inputs"]]
outs = [repr(fn(*a)) for a in inputs]
t = min(timeit.repeat(lambda: [fn(*a) for a in inputs], number=p["number"], repeat=3))
print(json.dumps({"outs": outs, "time": t}))
'''


def _run(code, func, inputs, number, timeout):
    payload = json.dumps({"code": code, "func": func, "inputs": inputs, "number": number})
    try:
        r = subprocess.run([sys.executable, "-c", RUNNER], input=payload, text=True,
                           capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"error": "timeout"}
    if r.returncode != 0:
        return {"error": r.stderr.strip().splitlines()[-1] if r.stderr.strip() else "runtime error"}
    return json.loads(r.stdout)


def verify(original: str, optimized: str, func: str, inputs: list, number=20, timeout=30):
    """inputs: list of strings, each a tuple literal of args, e.g. ["([1,2,3],)", "([],)"].
    Returns dict: valid_syntax, correct, speedup, error."""
    res = {"valid_syntax": True, "correct": False, "speedup": None, "error": None}
    try:
        ast.parse(optimized)
    except SyntaxError as e:
        res.update(valid_syntax=False, error=f"SyntaxError: {e}")
        return res
    a = _run(original, func, inputs, number, timeout)
    b = _run(optimized, func, inputs, number, timeout)
    if "error" in a or "error" in b:
        res["error"] = f"original: {a.get('error')} | optimized: {b.get('error')}"
        return res
    res["correct"] = a["outs"] == b["outs"]
    if res["correct"] and b["time"] > 0:
        res["speedup"] = a["time"] / b["time"]
    elif not res["correct"]:
        res["error"] = "Outputs differ"
    return res
