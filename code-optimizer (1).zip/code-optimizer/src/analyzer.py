"""Layer 1: rule-based analyzer. Walks the AST and flags known inefficient patterns."""
import ast


class Analyzer(ast.NodeVisitor):
    def __init__(self):
        self.issues = []          # list of (line, rule_id, message)
        self.loop_depth = 0

    def _add(self, node, rule, msg):
        self.issues.append((getattr(node, "lineno", 0), rule, msg))

    # ---------- loops ----------
    def _visit_loop(self, node):
        if self.loop_depth >= 1:
            self._add(node, "NESTED_LOOP", "Nested loop: possible O(n^2) or worse. Consider a dict/set lookup.")
        self.loop_depth += 1

        # range(len(x))
        if isinstance(node, ast.For) and isinstance(node.iter, ast.Call) \
                and getattr(node.iter.func, "id", "") == "range" and node.iter.args \
                and isinstance(node.iter.args[-1], ast.Call) \
                and getattr(node.iter.args[-1].func, "id", "") == "len":
            self._add(node, "RANGE_LEN", "range(len(x)): prefer 'for item in x' or enumerate(x).")

        # while i < len(x)
        if isinstance(node, ast.While):
            for c in ast.walk(node.test):
                if isinstance(c, ast.Call) and getattr(c.func, "id", "") == "len":
                    self._add(node, "LEN_IN_WHILE", "len() re-evaluated every iteration; cache it in a variable.")
                    break

        for stmt in node.body:
            for c in ast.walk(stmt):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr == "append":
                    if isinstance(node, ast.For):
                        self._add(node, "APPEND_LOOP", "append() in a for-loop: a list comprehension is usually faster.")
                    break
            for c in ast.walk(stmt):
                if isinstance(c, ast.AugAssign) and isinstance(c.op, ast.Add) and \
                        (isinstance(c.value, ast.Constant) and isinstance(c.value.value, str)
                         or isinstance(c.value, ast.JoinedStr)
                         or isinstance(c.value, ast.BinOp) and isinstance(c.value.op, ast.Add)
                         and any(isinstance(x, ast.Constant) and isinstance(x.value, str)
                                 for x in (c.value.left, c.value.right))):
                    self._add(c, "STR_CONCAT", "String += in a loop is O(n^2). Collect parts in a list and ''.join().")
                if isinstance(c, ast.Compare) and any(isinstance(o, (ast.In, ast.NotIn)) for o in c.ops) \
                        and not isinstance(c.comparators[0], (ast.Set, ast.Dict)):
                    self._add(c, "MEMBERSHIP", "'in' test inside a loop: if the container is a list, convert it to a set first.")
        self.generic_visit(node)
        self.loop_depth -= 1

    visit_For = _visit_loop
    visit_While = _visit_loop

    # ---------- calls ----------
    def visit_Call(self, node):
        name = getattr(node.func, "id", "")
        if name in ("sum", "any", "all", "min", "max") and node.args and isinstance(node.args[0], ast.ListComp):
            self._add(node, "LISTCOMP_IN_AGG", f"{name}([...]) builds a temporary list; use a generator expression.")
        self.generic_visit(node)

    def visit_Subscript(self, node):
        if isinstance(node.value, ast.Call) and getattr(node.value.func, "id", "") == "sorted" \
                and isinstance(node.slice, ast.Constant) and node.slice.value in (0, -1):
            self._add(node, "SORT_FOR_MINMAX", "sorted(x)[0]/[-1] is O(n log n); use min(x)/max(x).")
        self.generic_visit(node)


def analyze(code: str):
    """Return a list of (line, rule_id, message). Raises SyntaxError on bad code."""
    a = Analyzer()
    a.visit(ast.parse(code))
    return sorted(set(a.issues))


if __name__ == "__main__":
    import sys
    for line, rule, msg in analyze(open(sys.argv[1]).read()):
        print(f"line {line:>3} [{rule}] {msg}")
