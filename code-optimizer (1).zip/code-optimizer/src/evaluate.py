"""Evaluate rule-based (and optionally the ML model) on pairs that have func+inputs.
    python -m src.evaluate --data data/all.jsonl [--model models/codet5-opt]"""
import argparse, json
from src.rewriter import rewrite
from src.verifier import verify


def score(name, outputs, rows):
    valid = correct = faster = 0; sp = []
    for out, r in zip(outputs, rows):
        v = verify(r["slow"], out, r["func"], r["inputs"])
        valid += v["valid_syntax"]; correct += v["correct"]
        if v["speedup"]:
            sp.append(v["speedup"]); faster += v["speedup"] > 1.05
    n = len(rows)
    print(f"{name:<12} valid={valid/n:.0%}  correct={correct/n:.0%}  faster={faster/n:.0%}  "
          f"avg_speedup={sum(sp)/len(sp) if sp else 0:.2f}x")


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default="data/all.jsonl")
    ap.add_argument("--model"); a = ap.parse_args()
    rows = [json.loads(l) for l in open(a.data)]
    rows = [r for r in rows if "func" in r]
    score("rule-based", [rewrite(r["slow"])[0] for r in rows], rows)
    score("reference", [r["fast"] for r in rows], rows)
    if a.model:
        from src.model import load, optimize
        tok, m = load(a.model)
        score("codet5", [optimize(r["slow"], tok, m) for r in rows], rows)


if __name__ == "__main__":
    main()
