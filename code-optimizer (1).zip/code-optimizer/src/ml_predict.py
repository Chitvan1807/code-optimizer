"""One entry point for the ML bug-type prediction. Uses CodeBERT if you trained it, else the TF-IDF baseline."""
import os
from src.gen_data import LABELS

CODEBERT_DIR = "models/codebert-bugs"
BASELINE = "models/bug_clf.joblib"
_cache = {}


def available():
    return os.path.isdir(CODEBERT_DIR) or os.path.exists(BASELINE)


def predict(code: str):
    """Return (model_name, {label: probability})."""
    if os.path.isdir(CODEBERT_DIR):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        if "cb" not in _cache:
            _cache["cb"] = (AutoTokenizer.from_pretrained(CODEBERT_DIR),
                            AutoModelForSequenceClassification.from_pretrained(CODEBERT_DIR).eval())
        tok, m = _cache["cb"]
        with torch.no_grad():
            logits = m(**tok(code, return_tensors="pt", truncation=True, max_length=256)).logits[0]
        return "CodeBERT", {l: float(p) for l, p in zip(LABELS, torch.sigmoid(logits))}
    from src.ml_baseline import predict as p
    return "TF-IDF + LogisticRegression", p(code, BASELINE)
