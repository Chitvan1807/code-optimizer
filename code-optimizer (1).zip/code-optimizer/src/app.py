"""Streamlit UI.   Run:  streamlit run src/app.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
from src.checker import check
from src.analyzer import analyze
from src.rewriter import rewrite
from src.verifier import verify

st.set_page_config(page_title="Code Mistake Finder & Optimizer", layout="wide")
st.title("Code Mistake Finder & Optimizer")

EXAMPLE = open(os.path.join(os.path.dirname(__file__), "..", "examples", "buggy.py")).read() \
    if os.path.exists(os.path.join(os.path.dirname(__file__), "..", "examples", "buggy.py")) else ""
code = st.text_area("Paste your Python code", EXAMPLE, height=320)
tab1, tab2, tab3 = st.tabs(["Find mistakes", "ML bug-type prediction", "Optimize"])

ICON = {"error": "\U0001F534", "warning": "\U0001F7E0", "info": "\U0001F535"}

with tab1:
    if st.button("Find mistakes", type="primary"):
        rep = check(code)
        errs = sum(i.severity == "error" for i in rep.issues)
        warns = sum(i.severity == "warning" for i in rep.issues)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Errors", errs); c2.metric("Warnings", warns)
        c3.metric("Lines checked", rep.n_lines); c4.metric("Time", f"{rep.elapsed_ms:.1f} ms")
        if not rep.issues:
            st.success("No mistakes found.")
        lines = code.splitlines()
        for i in rep.issues:
            src = lines[i.line - 1].strip() if 1 <= i.line <= len(lines) else ""
            with st.container(border=True):
                st.markdown(f"{ICON[i.severity]} **Line {i.line}, col {i.col}** \u2014 `{i.code}`  \n{i.message}")
                if src: st.code(src, language="python")
                if i.hint: st.caption(f"Fix: {i.hint}")

with tab2:
    from src import ml_predict
    from src.gen_data import categories
    st.write("The ML model reads the code text and predicts **which kinds of mistakes** it contains. "
             "The rule-based checker gives the exact line; the ML model gives a learned second opinion.")
    if st.button("Predict bug types"):
        if not ml_predict.available():
            st.warning("No trained model yet. Run: python -m src.gen_data && python -m src.ml_baseline --train")
        else:
            name, probs = ml_predict.predict(code)
            st.caption(f"Model: {name}")
            truth = set(categories(code))
            for lab, pr in sorted(probs.items(), key=lambda kv: -kv[1]):
                c1, c2 = st.columns([3, 1])
                c1.progress(min(max(pr, 0.0), 1.0), text=f"{lab}  {pr:.0%}")
                c2.write("\u2714 checker agrees" if (pr >= 0.5) == (lab in truth) else "\u26A0 checker differs")

with tab3:
    c1, c2 = st.columns(2)
    func = c1.text_input("Function to test (optional)", "")
    inputs = c2.text_area("Test inputs, one tuple per line", "([1,2,3],)\n([],)", height=80)
    if st.button("Optimize"):
        try:
            issues = analyze(code)
        except SyntaxError as e:
            st.error(f"Fix the syntax error first (line {e.lineno}): {e.msg}"); st.stop()
        for line, rule, msg in issues: st.warning(f"Line {line} [{rule}]: {msg}")
        new, applied = rewrite(code)
        st.code(new, language="python")
        if applied: st.caption("Applied: " + "; ".join(applied))
        if func.strip():
            v = verify(code, new, func.strip(), [l for l in inputs.splitlines() if l.strip()])
            st.success(f"Output matches. Speedup {v['speedup']:.2f}x") if v["correct"] else st.error(v["error"])
