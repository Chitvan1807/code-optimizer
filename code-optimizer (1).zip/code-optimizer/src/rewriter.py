"""Layer 1b: safe automatic rewrites using ast.NodeTransformer."""
import ast


def _is_empty_list_assign(stmt):
    return (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1
            and isinstance(stmt.targets[0], ast.Name)
            and isinstance(stmt.value, ast.List) and not stmt.value.elts)


def _append_call(stmt, name):
    """If stmt is `name.append(expr)` return expr, else None."""
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
        c = stmt.value
        if (isinstance(c.func, ast.Attribute) and c.func.attr == "append"
                and isinstance(c.func.value, ast.Name) and c.func.value.id == name
                and len(c.args) == 1 and not c.keywords):
            return c.args[0]
    return None


def _reads(node, name):
    return any(isinstance(n, ast.Name) and n.id == name for n in ast.walk(node))


def _loop_to_comp(init, loop):
    """`res = []` + `for x in it: [if c:] res.append(e)`  ->  `res = [e for x in it [if c]]`"""
    if not (isinstance(loop, ast.For) and not loop.orelse and len(loop.body) == 1
            and isinstance(loop.target, (ast.Name, ast.Tuple))):
        return None
    name = init.targets[0].id
    body = loop.body[0]
    cond = None
    elt = _append_call(body, name)
    if elt is None and isinstance(body, ast.If) and not body.orelse and len(body.body) == 1:
        elt = _append_call(body.body[0], name)
        cond = body.test
    if elt is None:
        return None
    # unsafe if the result list is read by the element/condition/iterable itself
    if _reads(elt, name) or _reads(loop.iter, name) or (cond is not None and _reads(cond, name)):
        return None
    comp = ast.ListComp(
        elt=elt,
        generators=[ast.comprehension(target=loop.target, iter=loop.iter,
                                      ifs=[cond] if cond else [], is_async=0)])
    return ast.Assign(targets=[ast.Name(id=name, ctx=ast.Store())], value=comp)


class Rewriter(ast.NodeTransformer):
    def __init__(self):
        self.applied = []

    def _rewrite_body(self, stmts):
        out, i = [], 0
        while i < len(stmts):
            if i + 1 < len(stmts) and _is_empty_list_assign(stmts[i]):
                new = _loop_to_comp(stmts[i], stmts[i + 1])
                if new is not None:
                    self.applied.append(f"line {stmts[i].lineno}: append-loop -> list comprehension")
                    out.append(new)
                    i += 2
                    continue
            out.append(stmts[i])
            i += 1
        return out

    def generic_visit(self, node):
        super().generic_visit(node)
        for field in ("body", "orelse", "finalbody"):
            val = getattr(node, field, None)
            if isinstance(val, list) and val:
                setattr(node, field, self._rewrite_body(val))
        return node

    def visit_Call(self, node):
        self.generic_visit(node)
        name = getattr(node.func, "id", "")
        if name in ("sum", "any", "all", "min", "max") and len(node.args) == 1 \
                and isinstance(node.args[0], ast.ListComp):
            lc = node.args[0]
            node.args[0] = ast.GeneratorExp(elt=lc.elt, generators=lc.generators)
            self.applied.append(f"line {node.lineno}: {name}([...]) -> generator expression")
        return node

    def visit_Subscript(self, node):
        self.generic_visit(node)
        if isinstance(node.value, ast.Call) and getattr(node.value.func, "id", "") == "sorted" \
                and len(node.value.args) == 1 and not node.value.keywords \
                and isinstance(node.slice, ast.Constant) and node.slice.value in (0, -1):
            fn = "min" if node.slice.value == 0 else "max"
            self.applied.append(f"line {node.lineno}: sorted(x)[{node.slice.value}] -> {fn}(x)")
            return ast.Call(func=ast.Name(id=fn, ctx=ast.Load()), args=node.value.args, keywords=[])
        return node


def rewrite(code: str):
    """Return (new_code, list_of_applied_rewrites)."""
    tree = ast.parse(code)
    r = Rewriter()
    tree = r.visit(tree)
    ast.fix_missing_locations(tree)
    return ast.unparse(tree), r.applied
