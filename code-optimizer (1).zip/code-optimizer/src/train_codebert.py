"""Fine-tune CodeBERT for multi-label bug-type prediction (run on Colab GPU).

    pip install transformers datasets torch accelerate scikit-learn
    python -m src.gen_data --n 6000
    python -m src.train_codebert --out models/codebert-bugs --epochs 4

Same data + same 6 labels as the TF-IDF baseline, so the two are directly comparable.
"""
import argparse, json
import numpy as np
from datasets import Dataset
from sklearn.metrics import f1_score
from transformers import (AutoModelForSequenceClassification, AutoTokenizer, DataCollatorWithPadding,
                          Trainer, TrainingArguments)
from src.gen_data import LABELS

BASE = "microsoft/codebert-base"


def load(path):
    rows = [json.loads(l) for l in open(path)]
    return Dataset.from_list([{"text": r["code"], "labels": [float(l in r["labels"]) for l in LABELS]} for r in rows])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="models/codebert-bugs"); ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--bs", type=int, default=16); ap.add_argument("--lr", type=float, default=2e-5)
    a = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(BASE)
    model = AutoModelForSequenceClassification.from_pretrained(
        BASE, num_labels=len(LABELS), problem_type="multi_label_classification",
        id2label=dict(enumerate(LABELS)), label2id={l: i for i, l in enumerate(LABELS)})

    enc = lambda b: tok(b["text"], truncation=True, max_length=256)
    tr, va, te = [load(f"data/ml_{n}.jsonl").map(enc, batched=True, remove_columns=["text"]) for n in ("train", "val", "test")]

    def metrics(p):
        pred = (1 / (1 + np.exp(-p.predictions)) > 0.5).astype(int)
        return {"micro_f1": f1_score(p.label_ids, pred, average="micro", zero_division=0),
                "macro_f1": f1_score(p.label_ids, pred, average="macro", zero_division=0),
                "exact_match": float((pred == p.label_ids).all(axis=1).mean())}

    args = TrainingArguments(output_dir=a.out, num_train_epochs=a.epochs, per_device_train_batch_size=a.bs,
                             per_device_eval_batch_size=a.bs, learning_rate=a.lr, eval_strategy="epoch",
                             save_strategy="epoch", save_total_limit=1, load_best_model_at_end=True,
                             metric_for_best_model="micro_f1", logging_steps=50, report_to="none")
    t = Trainer(model=model, args=args, train_dataset=tr, eval_dataset=va, data_collator=DataCollatorWithPadding(tok),
                compute_metrics=metrics)
    t.train()
    print("UNSEEN-TEMPLATE TEST:", t.evaluate(te, metric_key_prefix="test"))
    model.save_pretrained(a.out); tok.save_pretrained(a.out)


if __name__ == "__main__":
    main()
