"""Fine-tune CodeT5 on slow->fast pairs.  Run on Colab GPU:
    python -m src.train --data data/train.jsonl --val data/val.jsonl --out models/codet5-opt --epochs 10
"""
import argparse, json
from datasets import Dataset
from transformers import (AutoTokenizer, T5ForConditionalGeneration, DataCollatorForSeq2Seq,
                          Seq2SeqTrainer, Seq2SeqTrainingArguments)
from src.model import PREFIX, BASE


def load_jsonl(p):
    rows = [json.loads(l) for l in open(p)]
    return Dataset.from_list([{"slow": r["slow"], "fast": r["fast"]} for r in rows])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--val", required=True)
    ap.add_argument("--out", default="models/codet5-opt")
    ap.add_argument("--epochs", type=int, default=10); ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=5e-5)
    a = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(BASE)
    model = T5ForConditionalGeneration.from_pretrained(BASE)

    def prep(b):
        x = tok([PREFIX + s for s in b["slow"]], max_length=512, truncation=True)
        x["labels"] = tok(b["fast"], max_length=512, truncation=True)["input_ids"]
        return x

    tr = load_jsonl(a.data); va = load_jsonl(a.val)
    tr = tr.map(prep, batched=True, remove_columns=tr.column_names)
    va = va.map(prep, batched=True, remove_columns=va.column_names)

    args = Seq2SeqTrainingArguments(
        output_dir=a.out, num_train_epochs=a.epochs, per_device_train_batch_size=a.bs,
        per_device_eval_batch_size=a.bs, learning_rate=a.lr, eval_strategy="epoch",
        save_strategy="epoch", save_total_limit=1, load_best_model_at_end=True,
        logging_steps=10, report_to="none")
    Seq2SeqTrainer(model=model, args=args, train_dataset=tr, eval_dataset=va,
                   data_collator=DataCollatorForSeq2Seq(tok, model=model)).train()
    model.save_pretrained(a.out); tok.save_pretrained(a.out)
    print("Saved to", a.out)


if __name__ == "__main__":
    main()
