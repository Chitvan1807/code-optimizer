"""Mistake finder: tells the user WHERE the mistake is (line:col), WHAT it is and HOW to fix it.

Covers: syntax errors, undefined / unassigned variables, loops, functions, types, logic bugs.
It only parses the code (never runs it), so it is safe and takes a few milliseconds.

    python -m src.checker examples/buggy.py
"""
import ast, builtins, difflib, io, re, sys, time, tokenize, warnings
from dataclasses import dataclass, field, asdict


@dataclass
class Issue:
    line: int
    col: int
    severity: str          # error | warning | info
    code: str
    message: str
    hint: str = ""


@dataclass
class Report:
    issues: list = field(default_factory=list)
    elapsed_ms: float = 0.0
    n_lines: int = 0

    def to_dicts(self):
        return [asdict(i) for i in self.issues]


BUILTINS = set(dir(builtins)) | {"__name__", "__file__", "__doc__", "__builtins__", "__spec__",
                                 "__package__", "__loader__", "__path__"}
SHADOW = {n for n in dir(builtins) if not n.startswith("_") and not n[0].isupper()} \
    - {"copyright", "credits", "license", "exit", "quit", "help"}
NONE_RETURNING = {"sort", "append", "extend", "reverse", "insert", "remove", "clear"}
PURE_CALLS = {"print", "len", "str", "int", "float", "abs", "min", "max", "sum", "round", "repr", "type", "isinstance", "bool", "sorted"}
MUTATORS = {"append", "remove", "pop", "insert", "extend", "clear", "sort", "reverse"}
SCOPE_NODES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda,
               ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)
FUNC_NODES = (ast.FunctionDef, ast.AsyncFunctionDef)
MATCH_BIND = tuple(getattr(ast, n) for n in ("MatchAs", "MatchStar") if hasattr(ast, n))

SYNTAX_HINTS = [
    ("expected ':'", "Add a ':' at the end of the if/elif/else/for/while/def/class line."),
    ("was never closed", "A bracket was opened but never closed. Add the matching ) ] or }."),
    ("unterminated string", "Close the string with a matching quote."),
    ("unterminated triple-quoted", "Close the triple-quoted string with \"\"\" or '''."),
    ("Perhaps you forgot a comma", "Put a ',' between the items."),
    ("expected an indented block", "Indent (4 spaces) the lines that belong inside the block."),
    ("unexpected indent", "This line is indented more than the previous one. Remove the extra spaces."),
    ("unindent does not match", "Indentation must line up with an earlier block. Don't mix tabs and spaces."),
    ("Missing parentheses in call to 'print'", "Python 3 needs print(...)."),
    ("Maybe you meant '==' or ':='", "Use '==' to compare values; '=' only assigns."),
    ("Maybe you meant '=='", "Use '==' to compare values; '=' only assigns."),
    ("cannot assign to", "The left side of '=' must be a variable name."),
    ("outside function", "'return' can only be used inside a def."),
    ("outside loop", "'break'/'continue' can only be used inside a for/while loop."),
    ("unmatched", "Extra closing bracket: remove it or add the missing opening one."),
    ("closing parenthesis", "Brackets don't match: check ( ) [ ] { } pairs."),
    ("EOL while scanning", "Close the string with a matching quote."),
    ("invalid syntax", "Check this line and the one above for a missing operator, colon, bracket or quote."),
]


def _hint(msg):
    for key, h in SYNTAX_HINTS:
        if key in msg:
            return h
    return "Fix the syntax on this line."


# ------------------------------------------------------------------ helpers
def _targets(node):
    if isinstance(node, ast.Name):
        yield node.id
    elif isinstance(node, (ast.Tuple, ast.List)):
        for e in node.elts:
            yield from _targets(e)
    elif isinstance(node, ast.Starred):
        yield from _targets(node.value)


def collect_bindings(body):
    """Names bound in this scope (not descending into nested scopes)."""
    bound, glob, nonloc = set(), set(), set()
    stack = list(body)
    while stack:
        n = stack.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(n.name)
            continue
        if isinstance(n, SCOPE_NODES):
            continue
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            bound.add(n.id)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                if a.name != "*":
                    bound.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
        elif isinstance(n, ast.Global):
            glob.update(n.names)
        elif isinstance(n, ast.Nonlocal):
            nonloc.update(n.names)
        elif MATCH_BIND and isinstance(n, MATCH_BIND) and n.name:
            bound.add(n.name)
        stack.extend(ast.iter_child_nodes(n))
    return bound, glob, nonloc


def has_break(stmts):
    for s in stmts:
        if isinstance(s, ast.Break):
            return True
        if isinstance(s, (ast.For, ast.While, ast.AsyncFor, ast.FunctionDef,
                          ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        for f in ("body", "orelse", "finalbody"):
            sub = getattr(s, f, None)
            if isinstance(sub, list) and has_break(sub):
                return True
        for h in getattr(s, "handlers", []) or []:
            if has_break(h.body):
                return True
        for c in getattr(s, "cases", []) or []:
            if has_break(c.body):
                return True
    return False


def _is_exit_call(n):
    return isinstance(n, ast.Call) and (
        (isinstance(n.func, ast.Name) and n.func.id in ("exit", "quit"))
        or (isinstance(n.func, ast.Attribute) and n.func.attr == "exit"))


def has_return_raise(stmts):
    stack = list(stmts)
    while stack:
        n = stack.pop()
        if isinstance(n, (ast.Return, ast.Raise)) or _is_exit_call(n):
            return True
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        stack.extend(ast.iter_child_nodes(n))
    return False


def is_true(t):
    return isinstance(t, ast.Constant) and bool(t.value)


def terminates(stmts):
    for s in stmts:
        if isinstance(s, (ast.Return, ast.Raise)):
            return True
        if isinstance(s, ast.Expr) and _is_exit_call(s.value):
            return True
        if isinstance(s, ast.If) and s.orelse and terminates(s.body) and terminates(s.orelse):
            return True
        if isinstance(s, ast.While) and is_true(s.test) and not has_break(s.body):
            return True
        if isinstance(s, ast.Try):
            if (terminates(s.body) and all(terminates(h.body) for h in s.handlers)) or terminates(s.finalbody):
                return True
        if isinstance(s, (ast.With, ast.AsyncWith)) and terminates(s.body):
            return True
        if hasattr(ast, "Match") and isinstance(s, ast.Match):
            return True   # avoid false positives
    return False


# ------------------------------------------------------------------ flow / scope analysis
class Scope:
    def __init__(self, kind, bound, parent=None, glob=(), nonloc=(), preset=()):
        self.kind, self.parent = kind, parent
        self.bound = set(bound)
        self.glob, self.nonloc = set(glob), set(nonloc)
        self.definite, self.maybe, self.dead = set(preset), set(preset), False


class FlowChecker:
    """Finds undefined names, use-before-assignment, possibly-undefined names, unreachable code."""

    def __init__(self, tree, issues):
        self.issues = issues
        self.star = any(isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names)
                        for n in ast.walk(tree))
        self.global_decl = {n for node in ast.walk(tree) if isinstance(node, ast.Global) for n in node.names}
        bound, _, _ = collect_bindings(tree.body)
        self.module = Scope("module", bound | self.global_decl)
        self.sc = self.module
        self.deferred = []
        self.tree = tree

    def add(self, node, sev, code, msg, hint=""):
        self.issues.append(Issue(getattr(node, "lineno", 1), getattr(node, "col_offset", 0) + 1, sev, code, msg, hint))

    def run(self):
        self.block(self.tree.body)
        while self.deferred:
            fn, parent = self.deferred.pop(0)
            self.function(fn, parent)

    # ---- scopes / state
    def flow_scope(self):
        s = self.sc
        while s.kind == "comp":
            s = s.parent
        return s

    def define(self, name):
        fs = self.flow_scope()
        fs.bound.add(name)
        if fs.kind != "lambda":
            fs.definite.add(name)
            fs.maybe.add(name)

    def snap(self):
        f = self.sc
        return (set(f.definite), set(f.maybe), f.dead)

    def restore(self, s):
        f = self.sc
        f.definite, f.maybe, f.dead = set(s[0]), set(s[1]), s[2]

    def merge(self, snaps):
        f = self.sc
        live = [s for s in snaps if not s[2]]
        allmaybe = set().union(*[s[1] for s in snaps])
        if not live:
            f.definite, f.maybe, f.dead = set(snaps[0][0]), allmaybe, True
        else:
            d = set(live[0][0])
            for s in live[1:]:
                d &= s[0]
            f.definite, f.maybe, f.dead = d, allmaybe, False

    # ---- name lookup
    def load(self, n):
        name = n.id
        if name in self.global_decl:
            return
        sc, fs = self.sc, self.flow_scope()
        s = sc
        while s is not None:
            if s.kind == "class" and s is not sc:
                s = s.parent
                continue
            if name in s.glob:
                if name in self.module.bound:
                    return
                break
            if name in s.bound or name in s.nonloc:
                if s is fs and fs.kind in ("module", "function", "class"):
                    if name in fs.definite:
                        return
                    if name in fs.maybe:
                        self.add(n, "warning", "W-MAYBE-UNDEFINED",
                                 f"'{name}' may be undefined here (it is assigned only in some branches/loops)",
                                 f"Give '{name}' a default value before the if/for/while/try block.")
                    else:
                        self.add(n, "error", "E-UNBOUND",
                                 f"'{name}' is used before it is assigned a value",
                                 f"Assign '{name}' a value before this line.")
                return
            s = s.parent
        if name in BUILTINS or self.star:
            return
        cands = set(BUILTINS)
        s = sc
        while s is not None:
            cands |= s.bound
            s = s.parent
        close = difflib.get_close_matches(name, cands, n=1, cutoff=0.75)
        hint = f"Did you mean '{close[0]}'?" if close else \
            f"Define '{name}' before using it (or check the spelling / missing import)."
        self.add(n, "error", "E-UNDEFINED", f"name '{name}' is not defined", hint)

    # ---- expressions
    def expr(self, n):
        if n is None:
            return
        t = type(n)
        if t is ast.Name:
            if isinstance(n.ctx, ast.Load):
                self.load(n)
            return
        if t is ast.Lambda:
            a = n.args
            for d in list(a.defaults) + [d for d in a.kw_defaults if d]:
                self.expr(d)
            params = [x.arg for x in a.posonlyargs + a.args + a.kwonlyargs]
            params += [a.vararg.arg] if a.vararg else []
            params += [a.kwarg.arg] if a.kwarg else []
            saved, self.sc = self.sc, Scope("lambda", params, self.sc, preset=params)
            self.expr(n.body)
            self.sc = saved
            return
        if t in (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp):
            gens = n.generators
            self.expr(gens[0].iter)
            names = set()
            for g in gens:
                names.update(_targets(g.target))
            saved, self.sc = self.sc, Scope("comp", names, self.sc, preset=names)
            for i, g in enumerate(gens):
                if i:
                    self.expr(g.iter)
                for c in g.ifs:
                    self.expr(c)
            if t is ast.DictComp:
                self.expr(n.key)
                self.expr(n.value)
            else:
                self.expr(n.elt)
            self.sc = saved
            return
        if t is ast.NamedExpr:
            self.expr(n.value)
            self.define(n.target.id)
            return
        for c in ast.iter_child_nodes(n):
            self.expr(c)

    def store(self, tg):
        if isinstance(tg, ast.Name):
            self.define(tg.id)
        elif isinstance(tg, (ast.Tuple, ast.List)):
            for e in tg.elts:
                self.store(e)
        elif isinstance(tg, ast.Starred):
            self.store(tg.value)
        else:
            self.expr(tg)

    # ---- statements
    def block(self, stmts):
        for st in stmts:
            if self.sc.dead:
                self.add(st, "warning", "W-UNREACHABLE",
                         "Unreachable code: it can never run (it follows return/break/continue/raise or an endless loop)",
                         "Remove this code or move it before the return/break.")
                return
            self.stmt(st)

    def function(self, fn, parent):
        a = fn.args
        params = [x.arg for x in a.posonlyargs + a.args + a.kwonlyargs]
        params += [a.vararg.arg] if a.vararg else []
        params += [a.kwarg.arg] if a.kwarg else []
        bound, glob, nonloc = collect_bindings(fn.body)
        sc = Scope("function", (bound - glob - nonloc) | set(params), parent, glob, nonloc, preset=params)
        saved, self.sc = self.sc, sc
        self.block(fn.body)
        self.sc = saved

    def stmt(self, n):
        t = type(n)
        f = self.sc
        if t is ast.Assign:
            self.expr(n.value)
            for tg in n.targets:
                self.store(tg)
        elif t is ast.AugAssign:
            self.expr(n.value)
            if isinstance(n.target, ast.Name):
                self.load(ast.copy_location(ast.Name(id=n.target.id, ctx=ast.Load()), n))
            else:
                self.expr(n.target)
            self.store(n.target)
        elif t is ast.AnnAssign:
            if n.value is not None:
                self.expr(n.value)
                self.store(n.target)
            elif not isinstance(n.target, ast.Name):
                self.expr(n.target)
        elif t is ast.Expr:
            self.expr(n.value)
            if _is_exit_call(n.value):
                f.dead = True
        elif t is ast.Return:
            self.expr(n.value)
            f.dead = True
        elif t is ast.Raise:
            self.expr(n.exc)
            self.expr(n.cause)
            f.dead = True
        elif t in (ast.Break, ast.Continue):
            f.dead = True
        elif t is ast.Assert:
            self.expr(n.test)
            self.expr(n.msg)
        elif t is ast.Delete:
            for tg in n.targets:
                if isinstance(tg, ast.Name):
                    f.definite.discard(tg.id)
                else:
                    self.expr(tg)
        elif t in (ast.Import, ast.ImportFrom):
            for a in n.names:
                if a.name != "*":
                    self.define((a.asname or a.name).split(".")[0])
        elif t is ast.If:
            self.expr(n.test)
            s0 = self.snap()
            self.block(n.body)
            s1 = self.snap()
            self.restore(s0)
            self.block(n.orelse)
            self.merge([s1, self.snap()])
        elif t in (ast.For, ast.AsyncFor):
            self.expr(n.iter)
            s0 = self.snap()
            f.maybe |= collect_bindings(n.body)[0]
            self.store(n.target)
            self.block(n.body)
            s1 = self.snap()
            f.definite, f.maybe, f.dead = set(s0[0]), s0[1] | s1[1] | set(_targets(n.target)), False
            self.block(n.orelse)
        elif t is ast.While:
            self.expr(n.test)
            s0 = self.snap()
            f.maybe |= collect_bindings(n.body)[0]
            self.block(n.body)
            s1 = self.snap()
            infinite = is_true(n.test) and not has_break(n.body)
            if is_true(n.test):
                f.definite, f.maybe, f.dead = set(s1[0]), s0[1] | s1[1], infinite
            else:
                f.definite, f.maybe, f.dead = set(s0[0]), s0[1] | s1[1], False
            if n.orelse and not infinite:
                self.block(n.orelse)
        elif t in (ast.Try,) or (hasattr(ast, "TryStar") and t is ast.TryStar):
            s0 = self.snap()
            self.block(n.body)
            st = self.snap()
            if n.orelse:
                self.block(n.orelse)
            snaps = [self.snap()]
            for h in n.handlers:
                self.restore((set(s0[0]), set(s0[1]) | st[1], False))
                self.expr(h.type)
                if h.name:
                    self.define(h.name)
                self.block(h.body)
                snaps.append(self.snap())
            self.merge(snaps)
            if n.finalbody:
                d, f.dead = f.dead, False
                self.block(n.finalbody)
                f.dead = d or f.dead
        elif t in (ast.With, ast.AsyncWith):
            for it in n.items:
                self.expr(it.context_expr)
                if it.optional_vars is not None:
                    self.store(it.optional_vars)
            self.block(n.body)
        elif t in FUNC_NODES:
            a = n.args
            for d in n.decorator_list + list(a.defaults) + [d for d in a.kw_defaults if d]:
                self.expr(d)
            self.define(n.name)
            self.deferred.append((n, f))
        elif t is ast.ClassDef:
            for d in n.decorator_list + n.bases + [k.value for k in n.keywords]:
                self.expr(d)
            bound, glob, _ = collect_bindings(n.body)
            saved, self.sc = self.sc, Scope("class", bound, self.sc, glob)
            self.block(n.body)
            self.sc = saved
            self.define(n.name)
        elif hasattr(ast, "Match") and t is ast.Match:
            self.expr(n.subject)
            s0, snaps = self.snap(), []
            for c in n.cases:
                self.restore(s0)
                for p in ast.walk(c.pattern):
                    if MATCH_BIND and isinstance(p, MATCH_BIND) and p.name:
                        self.define(p.name)
                    if hasattr(ast, "MatchMapping") and isinstance(p, ast.MatchMapping) and p.rest:
                        self.define(p.rest)
                self.expr(c.guard)
                self.block(c.body)
                snaps.append(self.snap())
            self.merge(snaps + [s0])
        elif t not in (ast.Pass, ast.Global, ast.Nonlocal):
            for c in ast.iter_child_nodes(n):
                self.expr(c)


# ------------------------------------------------------------------ logic checks
class LogicChecks(ast.NodeVisitor):
    def __init__(self, tree, lines, issues):
        self.issues, self.lines = issues, lines
        self.loop_stack = []
        defs = {}
        counts = {}
        for n in tree.body:
            if isinstance(n, FUNC_NODES):
                counts[n.name] = counts.get(n.name, 0) + 1
                defs[n.name] = n
        self.func_names = set(counts)
        self.funcs = {k: v for k, v in defs.items() if counts[k] == 1 and not v.decorator_list}
        # names that hold input() text (str) and are never reassigned from anything else
        from_input, other = set(), set()
        for n in ast.walk(tree):
            if isinstance(n, ast.Assign):
                is_in = isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == "input"
                for tg in n.targets:
                    for nm in _targets(tg):
                        (from_input if is_in else other).add(nm)
            elif isinstance(n, (ast.AugAssign, ast.For, ast.AnnAssign)):
                tg = n.target
                other.update(_targets(tg))
            elif isinstance(n, FUNC_NODES):
                a = n.args
                other.update(x.arg for x in a.posonlyargs + a.args + a.kwonlyargs)
        self.input_names = from_input - other

    def add(self, node, sev, code, msg, hint=""):
        self.issues.append(Issue(getattr(node, "lineno", 1), getattr(node, "col_offset", 0) + 1, sev, code, msg, hint))

    def _is_input(self, n):
        return (isinstance(n, ast.Name) and n.id in self.input_names) or \
               (isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "input")

    @staticmethod
    def _num(n):
        return isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool)

    # ---- functions / classes
    def visit_FunctionDef(self, n):
        a = n.args
        for d in list(a.defaults) + [d for d in a.kw_defaults if d]:
            if isinstance(d, (ast.List, ast.Dict, ast.Set)) or \
               (isinstance(d, ast.Call) and isinstance(d.func, ast.Name) and d.func.id in ("list", "dict", "set")):
                self.add(d, "warning", "W-MUTABLE-DEFAULT",
                         "Mutable default argument: the same list/dict is shared between all calls",
                         "Use None as the default and create the list/dict inside the function.")
        for x in a.posonlyargs + a.args + a.kwonlyargs:
            if x.arg in SHADOW:
                self.add(x, "info", "I-SHADOW", f"Parameter '{x.arg}' hides the built-in '{x.arg}'", "Rename it.")
        # return paths
        rets, is_gen = [], False
        stack = list(n.body)
        while stack:
            s = stack.pop()
            if isinstance(s, (ast.Yield, ast.YieldFrom)):
                is_gen = True
            if isinstance(s, ast.Return) and s.value is not None and not (isinstance(s.value, ast.Constant) and s.value.value is None):
                rets.append(s)
            if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                continue
            stack.extend(ast.iter_child_nodes(s))
        if rets and not is_gen and not terminates(n.body):
            self.add(n, "warning", "W-MISSING-RETURN",
                     f"Function '{n.name}' returns a value on some paths but may end without 'return' (gives None)",
                     "Add a return at the end or in the else-branch.")
        # recursion without base case
        calls_self = any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == n.name
                         for s in n.body for c in ast.walk(s))
        branching = any(isinstance(c, (ast.If, ast.IfExp, ast.Try, ast.For, ast.While, ast.BoolOp,
                                       ast.ListComp, ast.GeneratorExp) + ((ast.Match,) if hasattr(ast, "Match") else ()))
                        for s in n.body for c in ast.walk(s))
        if calls_self and not branching:
            self.add(n, "warning", "W-NO-BASE-CASE",
                     f"'{n.name}' calls itself with no condition: infinite recursion (RecursionError)",
                     "Add a base case such as 'if n == 0: return ...'.")
        saved, self.loop_stack = self.loop_stack, []
        self.generic_visit(n)
        self.loop_stack = saved

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, n):
        seen = set()
        for item in n.body:
            if isinstance(item, FUNC_NODES):
                if item.name in seen:
                    self.add(item, "warning", "W-REDEFINED", f"Method '{item.name}' is defined twice; the first one is lost")
                seen.add(item.name)
                decos = {getattr(d, "id", getattr(d, "attr", "")) for d in item.decorator_list}
                if "staticmethod" in decos or item.name in ("__new__", "__init_subclass__", "__class_getitem__"):
                    continue
                params = item.args.posonlyargs + item.args.args
                if not params and not item.args.vararg:
                    self.add(item, "error", "E-NO-SELF", f"Method '{item.name}' has no 'self' parameter",
                             "Add 'self' as the first parameter: def name(self, ...).")
                elif params:
                    want = "cls" if "classmethod" in decos else "self"
                    if params[0].arg not in (want, "cls", "self", "mcs", "metacls"):
                        self.add(item, "warning", "W-SELF-NAME",
                                 f"First parameter of method '{item.name}' is '{params[0].arg}', expected '{want}'")
        self.generic_visit(n)

    def visit_Module(self, n):
        self._dup_defs(n.body)
        self.generic_visit(n)

    def _dup_defs(self, body):
        seen = {}
        for s in body:
            if isinstance(s, FUNC_NODES):
                if s.name in seen:
                    self.add(s, "warning", "W-REDEFINED",
                             f"Function '{s.name}' is already defined on line {seen[s.name]}; the earlier one is overwritten")
                seen[s.name] = s.lineno

    # ---- conditions
    def _test(self, t, node):
        if isinstance(t, ast.Constant) and not isinstance(node, ast.While):
            self.add(t, "warning", "W-CONST-CONDITION", f"Condition is always {bool(t.value)}",
                     "Replace the constant with a real comparison.")
        elif isinstance(t, ast.Tuple) and t.elts:
            self.add(t, "warning", "W-TUPLE-CONDITION", "A non-empty tuple is always True",
                     "Remove the extra parentheses/commas, or use 'and'.")
        elif isinstance(t, ast.Name) and t.id in self.func_names:
            self.add(t, "warning", "W-FUNC-CONDITION",
                     f"'{t.id}' is a function object (always True). Did you forget the call?", f"Use {t.id}().")

    def visit_If(self, n):
        self._test(n.test, n)
        self.generic_visit(n)

    def visit_IfExp(self, n):
        self._test(n.test, n)
        self.generic_visit(n)

    def visit_Compare(self, n):
        for op, right in zip(n.ops, n.comparators):
            left = n.left if right is n.comparators[0] else n.comparators[n.comparators.index(right) - 1]
            if isinstance(op, (ast.Eq, ast.NotEq)):
                for side in (left, right):
                    if isinstance(side, ast.Constant) and side.value is None:
                        self.add(n, "warning", "W-NONE-COMPARE", "Comparing to None with ==/!=",
                                 "Use 'is None' / 'is not None'.")
                        break
                    if isinstance(side, ast.Constant) and isinstance(side.value, bool):
                        self.add(n, "warning", "W-BOOL-COMPARE", "Comparing to True/False with ==",
                                 "Just use 'if x:' or 'if not x:'.")
                        break
                if (self._is_input(left) and self._num(right)) or (self._is_input(right) and self._num(left)):
                    self.add(n, "error", "E-INPUT-STR", "input() returns text (str), so it is never equal to a number",
                             "Convert first: int(input(...)).")
            elif isinstance(op, (ast.Is, ast.IsNot)):
                for side in (left, right):
                    if isinstance(side, ast.Constant) and isinstance(side.value, (str, bytes, int, float)) \
                            and not isinstance(side.value, bool):
                        self.add(n, "warning", "W-IS-LITERAL", "'is' compares identity, not value, for numbers/strings",
                                 "Use '==' / '!=' instead.")
                        break
            elif isinstance(op, (ast.Lt, ast.Gt, ast.LtE, ast.GtE)):
                if (self._is_input(left) and self._num(right)) or (self._is_input(right) and self._num(left)):
                    self.add(n, "error", "E-INPUT-STR", "Comparing input() text (str) with a number raises TypeError",
                             "Convert first: int(input(...)) or float(input(...)).")
        self.generic_visit(n)

    def visit_BoolOp(self, n):
        if isinstance(n.op, ast.Or) and len(n.values) > 1 and isinstance(n.values[0], ast.Compare) \
                and any(isinstance(v, ast.Constant) and not isinstance(v.value, bool) for v in n.values[1:]):
            self.add(n, "warning", "W-OR-CONSTANT",
                     "'x == a or b': the second part is just a constant, so this is always True",
                     "Write it fully: x == a or x == b  (or: x in (a, b)).")
        self.generic_visit(n)

    # ---- loops
    def visit_For(self, n):
        t = set(_targets(n.target))
        outer = set().union(*self.loop_stack) if self.loop_stack else set()
        if t & outer:
            self.add(n, "warning", "W-LOOPVAR-REUSE",
                     f"Inner loop reuses the loop variable '{sorted(t & outer)[0]}' of an outer loop",
                     "Use a different variable name in the inner loop.")
        it = n.iter
        if isinstance(it, ast.Call) and isinstance(it.func, ast.Name):
            if it.func.id == "len":
                self.add(n, "error", "E-FOR-LEN", "len() returns an int, which cannot be looped over",
                         "Use: for i in range(len(x)):  or loop directly: for item in x:")
            elif it.func.id == "range":
                self._range(n, it, t)
        elif self._num(it):
            self.add(n, "error", "E-FOR-NUMBER", "A number is not iterable", "Use range(n).")
        # modifying the list being iterated
        if isinstance(it, ast.Name):
            for s in n.body:
                for c in ast.walk(s):
                    if isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr in MUTATORS \
                            and isinstance(c.func.value, ast.Name) and c.func.value.id == it.id:
                        self.add(c, "warning", "W-MODIFY-WHILE-ITERATING",
                                 f"'{it.id}' is changed while the loop is iterating over it (items get skipped)",
                                 f"Loop over a copy: for x in {it.id}[:]  or build a new list.")
                    if isinstance(c, ast.Delete) and any(isinstance(d, ast.Subscript) and isinstance(d.value, ast.Name)
                                                         and d.value.id == it.id for d in c.targets):
                        self.add(c, "warning", "W-MODIFY-WHILE-ITERATING", f"Deleting from '{it.id}' while iterating over it")
        for s in n.body:
            for c in ast.walk(s):
                if isinstance(c, ast.Assign) and any(set(_targets(tg)) & t for tg in c.targets):
                    self.add(c, "info", "I-LOOPVAR-ASSIGN", "Assigning to the loop variable has no effect on the loop",
                             "Use a different variable name.")
        for nm in t:
            if nm in SHADOW:
                self.add(n, "warning", "W-SHADOW", f"Loop variable '{nm}' hides the built-in '{nm}'", "Rename it.")
        self.loop_stack.append(t)
        self.generic_visit(n)
        self.loop_stack.pop()

    visit_AsyncFor = visit_For

    def _range(self, n, call, targets):
        a = call.args
        if not a or len(a) > 3:
            self.add(call, "error", "E-RANGE-ARGS", "range() takes 1 to 3 arguments")
            return
        if any(isinstance(x, ast.Constant) and isinstance(x.value, float) for x in a):
            self.add(call, "error", "E-RANGE-FLOAT", "range() needs integers, not floats", "Use int(...) or //.")
        if len(a) == 3 and isinstance(a[2], ast.Constant) and a[2].value == 0:
            self.add(call, "error", "E-RANGE-STEP", "range() step cannot be 0")
        if len(a) >= 2 and all(isinstance(x, ast.Constant) and isinstance(x.value, int) for x in a[:2]):
            step = a[2].value if len(a) == 3 and isinstance(a[2], ast.Constant) else 1
            if isinstance(step, int) and step > 0 and a[0].value >= a[1].value:
                self.add(call, "warning", "W-EMPTY-RANGE", "This range is empty: the loop body never runs",
                         "The start must be smaller than the stop (or use a negative step).")
        stop = a[-1]
        if isinstance(stop, ast.BinOp) and isinstance(stop.op, ast.Add):
            for l, c in ((stop.left, stop.right), (stop.right, stop.left)):
                if isinstance(l, ast.Call) and isinstance(l.func, ast.Name) and l.func.id == "len" and l.args \
                        and isinstance(l.args[0], ast.Name) and isinstance(c, ast.Constant) \
                        and isinstance(c.value, int) and c.value > 0:
                    X = l.args[0].id
                    for s in n.body:
                        for sub in ast.walk(s):
                            if isinstance(sub, ast.Subscript) and isinstance(sub.value, ast.Name) and sub.value.id == X \
                                    and isinstance(sub.slice, ast.Name) and sub.slice.id in targets:
                                self.add(call, "warning", "W-OFF-BY-ONE",
                                         f"range goes past the end of '{X}': {X}[{sub.slice.id}] will raise IndexError on the last pass",
                                         f"Use range(len({X})).")
                                return

    def visit_While(self, n):
        if is_true(n.test):
            if not has_break(n.body) and not has_return_raise(n.body):
                self.add(n, "error", "E-INFINITE-LOOP", "Infinite loop: 'while True' has no break/return/exit inside",
                         "Add a condition that becomes False, or a 'break' when done.")
        else:
            test_calls = {id(c.func) for c in ast.walk(n.test) if isinstance(c, ast.Call)}
            names = {c.id for c in ast.walk(n.test) if isinstance(c, ast.Name) and isinstance(c.ctx, ast.Load)
                     and id(c) not in test_calls}
            if names and not has_break(n.body) and not has_return_raise(n.body):
                modified = False
                for s in n.body:
                    for c in ast.walk(s):
                        if isinstance(c, ast.Name) and isinstance(c.ctx, (ast.Store, ast.Del)) and c.id in names:
                            modified = True
                        elif isinstance(c, ast.Call):
                            if isinstance(c.func, ast.Attribute) and isinstance(c.func.value, ast.Name) \
                                    and c.func.value.id in names:
                                modified = True
                            pure = isinstance(c.func, ast.Name) and c.func.id in PURE_CALLS
                            if not pure and any(isinstance(x, ast.Name) and x.id in names for x in c.args):
                                modified = True
                            if isinstance(c.func, ast.Name) and c.func.id in ("input", "next", "readline"):
                                modified = True
                        elif isinstance(c, (ast.Global, ast.Nonlocal)):
                            modified = True
                if not modified:
                    self.add(n, "warning", "W-LOOP-NOCHANGE",
                             f"Variable(s) {', '.join(sorted(names))} in the while-condition are never changed in the loop body: possible infinite loop",
                             "Update the variable inside the loop (e.g. i += 1).")
        self._test(n.test, n)
        self.generic_visit(n)

    # ---- assignments / expressions
    def visit_Assign(self, n):
        v = n.value
        if len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and isinstance(v, ast.Name) \
                and v.id == n.targets[0].id:
            self.add(n, "warning", "W-SELF-ASSIGN", f"'{v.id} = {v.id}' does nothing")
        if isinstance(v, ast.Call) and isinstance(v.func, ast.Attribute) and v.func.attr in NONE_RETURNING:
            self.add(n, "warning", "W-NONE-RESULT",
                     f".{v.func.attr}() changes the list in place and returns None, so the variable becomes None",
                     f"Call it on its own line: x.{v.func.attr}(...)  (for sorting a copy use sorted(x)).")
        for tg in n.targets:
            for nm in _targets(tg):
                if nm in SHADOW:
                    self.add(n, "warning", "W-SHADOW", f"Variable '{nm}' hides the built-in '{nm}'",
                             "Rename it (e.g. 'total' instead of 'sum').")
        if 1 <= n.lineno <= len(self.lines):
            m = re.search(r"(\w+)\s+=([+-])\s+\w", self.lines[n.lineno - 1])
            if m:
                self.add(n, "warning", "W-TYPO-AUGASSIGN", f"'{m.group(1)} ={m.group(2)} ...' looks like a typo",
                         f"Did you mean '{m.group(1)} {m.group(2)}= ...'?")
        self.generic_visit(n)

    def visit_BinOp(self, n):
        l, r = n.left, n.right
        if isinstance(n.op, (ast.Div, ast.FloorDiv, ast.Mod)) and isinstance(r, ast.Constant) \
                and isinstance(r.value, (int, float)) and r.value == 0:
            self.add(n, "error", "E-DIV-ZERO", "Division by zero (ZeroDivisionError)")
        if isinstance(n.op, ast.Add):
            s = lambda x: isinstance(x, ast.Constant) and isinstance(x.value, str)
            if (s(l) and self._num(r)) or (self._num(l) and s(r)):
                self.add(n, "error", "E-STR-PLUS-NUM", "Cannot add a string and a number (TypeError)",
                         "Convert with str(number) or use an f-string.")
            elif (self._is_input(l) and self._num(r)) or (self._is_input(r) and self._num(l)):
                self.add(n, "error", "E-INPUT-STR", "input() returns text: adding a number to it raises TypeError",
                         "Convert first: int(input(...)).")
        elif isinstance(n.op, (ast.Sub, ast.Div, ast.FloorDiv, ast.Pow)) and (self._is_input(l) or self._is_input(r)):
            self.add(n, "error", "E-INPUT-STR", "input() returns text (str); arithmetic on it raises TypeError",
                     "Convert first: int(input(...)) or float(input(...)).")
        self.generic_visit(n)

    def visit_Subscript(self, n):
        if isinstance(n.value, ast.Name) and isinstance(n.slice, ast.Call) and isinstance(n.slice.func, ast.Name) \
                and n.slice.func.id == "len" and n.slice.args and isinstance(n.slice.args[0], ast.Name) \
                and n.slice.args[0].id == n.value.id and isinstance(n.ctx, ast.Load):
            self.add(n, "error", "E-INDEX-LEN", f"{n.value.id}[len({n.value.id})] is out of range: the last index is len-1",
                     f"Use {n.value.id}[-1] or {n.value.id}[len({n.value.id}) - 1].")
        self.generic_visit(n)

    def visit_Dict(self, n):
        seen = set()
        for k in n.keys:
            if isinstance(k, ast.Constant):
                key = repr(k.value)
                if key in seen:
                    self.add(k, "warning", "W-DUP-KEY", f"Duplicate dictionary key {key}: the earlier value is overwritten")
                seen.add(key)
        self.generic_visit(n)

    def visit_ExceptHandler(self, n):
        if n.type is None:
            self.add(n, "warning", "W-BARE-EXCEPT", "Bare 'except:' also catches Ctrl+C and hides real bugs",
                     "Catch specific errors, e.g. 'except ValueError:'.")
        if len(n.body) == 1 and isinstance(n.body[0], ast.Pass):
            self.add(n, "warning", "W-SWALLOWED-ERROR", "The error is silently ignored (except ...: pass)",
                     "At least print or log the error.")
        self.generic_visit(n)

    def visit_Assert(self, n):
        if isinstance(n.test, ast.Tuple) and n.test.elts:
            self.add(n, "warning", "W-ASSERT-TUPLE", "assert on a tuple is always True",
                     "Write: assert cond, 'message'  (no parentheses around both).")
        self.generic_visit(n)

    def visit_Call(self, n):
        f = n.func
        if isinstance(f, ast.Attribute) and f.attr == "append" and (len(n.args) != 1 or n.keywords):
            self.add(n, "error", "E-APPEND-ARGS", "append() takes exactly one argument",
                     "To add several items use extend([...]) or append a tuple/list.")
        if isinstance(f, ast.Name) and f.id in self.funcs:
            self._arity(n, self.funcs[f.id])
        self.generic_visit(n)

    def _arity(self, call, fn):
        if any(isinstance(x, ast.Starred) for x in call.args) or any(k.arg is None for k in call.keywords):
            return
        a = fn.args
        pos = [x.arg for x in a.posonlyargs + a.args]
        required = pos[:len(pos) - len(a.defaults)]
        kw = [k.arg for k in call.keywords]
        name = fn.name
        if len(call.args) > len(pos) and not a.vararg:
            self.add(call, "error", "E-TOO-MANY-ARGS",
                     f"{name}() takes at most {len(pos)} argument(s) but {len(call.args)} were given")
            return
        provided = set(pos[:len(call.args)]) | set(kw)
        missing = [r for r in required if r not in provided]
        missing += [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None and x.arg not in kw]
        if missing:
            self.add(call, "error", "E-MISSING-ARGS", f"{name}() is missing required argument(s): {', '.join(missing)}",
                     f"Definition is on line {fn.lineno}.")
        allowed = set(pos) | {x.arg for x in a.kwonlyargs}
        for k in kw:
            if k not in allowed and not a.kwarg:
                self.add(call, "error", "E-UNKNOWN-KWARG", f"{name}() got an unexpected keyword argument '{k}'")
            elif k in pos[:len(call.args)]:
                self.add(call, "error", "E-DUP-ARG", f"{name}() got multiple values for argument '{k}'")


# ------------------------------------------------------------------ unused names
def unused_checks(tree, issues):
    loaded = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    for n in ast.walk(tree):
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__all__" for t in n.targets):
            loaded |= {e.value for e in ast.walk(n.value) if isinstance(e, ast.Constant) and isinstance(e.value, str)}
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            if isinstance(n, ast.ImportFrom) and n.module == "__future__":
                continue
            for a in n.names:
                nm = (a.asname or a.name).split(".")[0]
                if nm != "*" and nm not in loaded:
                    issues.append(Issue(n.lineno, n.col_offset + 1, "warning", "W-UNUSED-IMPORT",
                                        f"'{nm}' is imported but never used", "Remove the import."))
    for fn in ast.walk(tree):
        if not isinstance(fn, FUNC_NODES):
            continue
        glob = {x for s in ast.walk(fn) if isinstance(s, (ast.Global, ast.Nonlocal)) for x in s.names}
        fln = {x.id for s in ast.walk(fn) for x in ast.walk(s) if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Load)}
        seen = set()
        for s in ast.walk(fn):
            tg = []
            if isinstance(s, ast.Assign):
                tg = [t for t in s.targets if isinstance(t, ast.Name)]
            elif isinstance(s, ast.AnnAssign) and s.value is not None and isinstance(s.target, ast.Name):
                tg = [s.target]
            for t in tg:
                if t.id not in fln and t.id not in glob and not t.id.startswith("_") and t.id not in seen \
                        and "locals" not in fln:
                    seen.add(t.id)
                    issues.append(Issue(t.lineno, t.col_offset + 1, "info", "I-UNUSED-VAR",
                                        f"Variable '{t.id}' is assigned but never used",
                                        "Remove it, or use it (or name it '_')."))


# ------------------------------------------------------------------ syntax helpers
def _scan_tokens(code):
    """Extra syntax findings (several at once): unclosed/mismatched brackets, missing colons."""
    out, stack, line_toks = [], [], []
    pairs = {")": "(", "]": "[", "}": "{"}
    kws = {"if", "elif", "else", "for", "while", "def", "class", "try", "except", "finally", "with"}
    try:
        for tok in tokenize.generate_tokens(io.StringIO(code).readline):
            tt, s, (sl, sc) = tok[0], tok[1], tok[2]
            if tt == tokenize.OP:
                if s in ("(", "[", "{"):
                    stack.append((s, sl, sc))
                elif s in pairs:
                    if not stack:
                        out.append(Issue(sl, sc + 1, "error", "E-BRACKET", f"Unmatched '{s}'",
                                         "Remove it or add the matching opening bracket."))
                    else:
                        if stack[-1][0] != pairs[s]:
                            o = stack[-1]
                            out.append(Issue(sl, sc + 1, "error", "E-BRACKET",
                                             f"'{s}' does not match the '{o[0]}' opened on line {o[1]}",
                                             "Check the order and type of brackets."))
                        stack.pop()
            if tt in (tokenize.COMMENT, tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER):
                continue
            if tt == tokenize.NEWLINE:
                if line_toks and line_toks[0][0] == tokenize.NAME and line_toks[0][1] in kws:
                    depth, colon = 0, False
                    for t in line_toks:
                        if t[0] == tokenize.OP:
                            if t[1] in "([{":
                                depth += 1
                            elif t[1] in ")]}":
                                depth -= 1
                            elif t[1] == ":" and depth == 0:
                                colon = True
                    if not colon:
                        kw = line_toks[0]
                        out.append(Issue(kw[2][0], kw[2][1] + 1, "error", "E-COLON",
                                         f"Missing ':' at the end of this '{kw[1]}' line",
                                         "Add ':' at the end of the line."))
                line_toks = []
            else:
                line_toks.append(tok)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass
    for s, l, c in stack:
        out.append(Issue(l, c + 1, "error", "E-BRACKET", f"'{s}' is opened here but never closed",
                         "Add the matching closing bracket."))
    return out


def _syntax_issue(e):
    msg = getattr(e, "msg", str(e)) or "invalid syntax"
    return Issue(e.lineno or 1, (e.offset or 1), "error", "E-SYNTAX", msg, _hint(msg))


# ------------------------------------------------------------------ public API
def check(code: str, filename="<input>") -> Report:
    t0 = time.perf_counter()
    issues, lines = [], code.splitlines()
    try:
        tree = ast.parse(code, filename)
    except SyntaxError as e:
        primary = _syntax_issue(e)
        issues.append(primary)
        for extra in _scan_tokens(code):
            if extra.line != primary.line:
                issues.append(extra)
        issues.sort(key=lambda i: (i.line, i.col))
        return Report(issues, (time.perf_counter() - t0) * 1000, len(lines))
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            compile(tree, filename, "exec")
    except SyntaxError as e:
        issues.append(_syntax_issue(e))
    except (ValueError, RecursionError):
        pass
    FlowChecker(tree, issues).run()
    LogicChecks(tree, lines, issues).visit(tree)
    unused_checks(tree, issues)
    uniq, seen = [], set()
    for i in sorted(issues, key=lambda i: (i.line, i.col, i.code)):
        k = (i.line, i.code, i.message)
        if k not in seen:
            seen.add(k)
            uniq.append(i)
    return Report(uniq, (time.perf_counter() - t0) * 1000, len(lines))


def format_report(code, rep: Report) -> str:
    lines, out = code.splitlines(), []
    for i in rep.issues:
        out.append(f"line {i.line}:{i.col}  {i.severity.upper():7} [{i.code}] {i.message}")
        if 1 <= i.line <= len(lines):
            out.append(f"      > {lines[i.line - 1].strip()}")
        if i.hint:
            out.append(f"      fix: {i.hint}")
    errs = sum(i.severity == "error" for i in rep.issues)
    out.append(f"\n{len(rep.issues)} issue(s), {errs} error(s) in {rep.n_lines} lines, checked in {rep.elapsed_ms:.1f} ms")
    return "\n".join(out)


if __name__ == "__main__":
    src = open(sys.argv[1]).read() if len(sys.argv) > 1 else sys.stdin.read()
    print(format_report(src, check(src)))
