import random
from src.gen_data import categories, make_sample, build, LABELS, TRAIN_IDS, TEMPLATES
from src.ml_baseline import normalize


def test_labels_from_checker():
    assert categories("def f(x)\n    return x\n") == ["syntax"]
    assert categories("def f(x):\n    return x\n") == []


def test_normalize_is_name_independent():
    a = normalize("def foo(nums):\n    return nums[0]\n")
    b = normalize("def bar(data):\n    return data[0]\n")
    assert a == b


def test_generator_makes_labelled_samples():
    rng = random.Random(1)
    got = [make_sample([rng.choice(TRAIN_IDS)], rng) for _ in range(40)]
    got = [g for g in got if g]
    assert got and all(set(l) <= set(LABELS) for _, l in got)


def test_split_has_unseen_templates():
    tr, va, te = build(60, seed=3, use_stdlib=False)
    assert set(sum([r["templates"] for r in te], [])).isdisjoint(set(sum([r["templates"] for r in tr + va], [])))


def test_stdlib_functions_are_clean_and_split_by_module():
    from src.gen_data import stdlib_functions
    std = stdlib_functions()
    assert len(std["train"]) > 100 and len(std["test"]) > 20
    assert set(std["train"]).isdisjoint(std["test"])
    assert all(categories(c) == [] for c in std["train"][:20])


def test_every_template_is_clean():
    rng = random.Random(0)
    from src.gen_data import make_clean
    for i in range(len(TEMPLATES)):
        assert categories(make_clean([i], rng)) == [], i
