from src.checker import check


def codes(src):
    return {i.code for i in check(src).issues}


def test_clean_code_has_no_errors():
    src = "def add(a, b):\n    return a + b\n\nprint(add(1, 2))\n"
    assert not [i for i in check(src).issues if i.severity == "error"]


def test_syntax_missing_colon_and_bracket():
    r = check("def f(x)\n    print((x)\n")
    assert r.issues[0].code == "E-SYNTAX" and r.issues[0].line == 1


def test_undefined_and_typo_hint():
    r = check("total = 5\nprint(totl)\n")
    i = [x for x in r.issues if x.code == "E-UNDEFINED"][0]
    assert i.line == 2 and "total" in i.hint


def test_use_before_assign_and_maybe():
    assert "E-UNBOUND" in codes("def f():\n    print(x)\n    x = 1\n")
    assert "W-MAYBE-UNDEFINED" in codes("if input():\n    y = 1\nprint(y)\n")


def test_loops():
    assert "E-FOR-LEN" in codes("a=[1]\nfor i in len(a):\n    pass\n")
    assert "E-INFINITE-LOOP" in codes("while True:\n    print(1)\n")
    assert "W-LOOP-NOCHANGE" in codes("i=0\nwhile i<3:\n    print(i)\n")
    assert "W-OFF-BY-ONE" in codes("a=[1]\nfor i in range(len(a)+1):\n    print(a[i])\n")
    assert "W-MODIFY-WHILE-ITERATING" in codes("a=[1]\nfor x in a:\n    a.remove(x)\n")


def test_functions():
    src = "def f(a, b):\n    return a\nf(1)\nf(1, 2, 3)\n"
    assert {"E-MISSING-ARGS", "E-TOO-MANY-ARGS"} <= codes(src)
    assert "W-MUTABLE-DEFAULT" in codes("def f(x=[]):\n    return x\n")
    assert "W-MISSING-RETURN" in codes("def f(x):\n    if x:\n        return 1\n")


def test_types_and_logic():
    assert "E-INPUT-STR" in codes("a = input()\nif a > 5:\n    pass\n")
    assert "E-STR-PLUS-NUM" in codes("print('a' + 1)\n")
    assert "E-DIV-ZERO" in codes("print(1/0)\n")
    assert "W-NONE-COMPARE" in codes("x=1\nif x == None:\n    pass\n")
    assert "W-UNREACHABLE" in codes("def f():\n    return 1\n    print(2)\n")


def test_speed():
    src = "x = 1\n" * 2000
    assert check(src).elapsed_ms < 500
