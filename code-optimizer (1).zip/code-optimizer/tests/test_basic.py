from src.analyzer import analyze
from src.rewriter import rewrite
from src.verifier import verify
from src.sample_data import PAIRS


def test_analyzer_flags():
    assert "NESTED_LOOP" in {r for _, r, _ in analyze(PAIRS[4]["slow"])}
    assert "APPEND_LOOP" in {r for _, r, _ in analyze(PAIRS[0]["slow"])}
    assert "STR_CONCAT" in {r for _, r, _ in analyze(PAIRS[5]["slow"])}


def test_rewrite_append_loop():
    new, applied = rewrite(PAIRS[1]["slow"])
    assert "for n in nums if n % 2 == 0" in new and applied


def test_rewrite_is_correct():
    for p in PAIRS[:4]:
        new, _ = rewrite(p["slow"])
        assert verify(p["slow"], new, p["func"], p["inputs"], number=2)["correct"]
