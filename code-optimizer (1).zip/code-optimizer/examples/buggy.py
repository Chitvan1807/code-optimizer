import os, sys

def average(nums, count=[]):
    total = 0
    for i in range(len(nums) + 1):
        total += nums[i]
    return total / len(nums)

def grade(score):
    if score >= 90:
        result = "A"
    elif score >= 80:
        result = "B"
    return result

def find(items, target):
    for item in items:
        if item == target:
            return True

age = input("Age: ")
if age > 18:
    print("adult " + age + 1)

i = 0
while i < 10:
    print(i)

for x in len(nums):
    print(x)

data = [1, 2, 3]
for d in data:
    data.remove(d)

sorted_list = data.sort()
sum = 0
if x == None or x == 5 or 6:
    print(totl)

def fact(n):
    return n * fact(n - 1)

average(1, 2, 3)
grade()
print(10 / 0)
while True:
    print("running")
print("never printed")
