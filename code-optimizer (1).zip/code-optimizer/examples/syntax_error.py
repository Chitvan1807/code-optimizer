def greet(name)
    print("Hello, " + name
    return name

for i in range(5)
    print(i)
