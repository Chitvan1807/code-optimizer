# Code Mistake Finder & Optimization Assistant

Hybrid pipeline: **AST analyzer -> rule-based rewriter + CodeT5 model -> verifier (correctness + speedup)** with a Streamlit UI.

## Setup
    pip install -r requirements.txt

## Steps
1. `python -m src.data_prep`            # builds data/train|val|test|all.jsonl (add more pairs in src/sample_data.py or --extra file)
2. `python -m src.evaluate`             # evaluates rule-based baseline vs reference
3. `python -m src.train --data data/train.jsonl --val data/val.jsonl --out models/codet5-opt --epochs 10`   # use Colab GPU
4. `python -m src.evaluate --model models/codet5-opt`   # compare model vs baseline (put this table in your report)
5. `streamlit run src/app.py`           # demo UI
6. `pytest`                             # sanity tests

## Notes
- 10 sample pairs only prove the pipeline works. For real training collect 500+ pairs (PIE dataset / CodeNet / your own).
- The verifier executes code in a subprocess with a timeout, but do not run untrusted code on a machine you care about.
- Test inputs must not be mutated by the function for timing to be fair.

## Mistake finder (src/checker.py)
    python -m src.checker examples/buggy.py        # prints line:col, what is wrong, how to fix it, and time taken
Detects: syntax errors (missing colon/bracket/quote, bad indentation), undefined or misspelled variables (with
"did you mean"), use-before-assignment, variables defined only in some branches, wrong loops (for x in len(a),
off-by-one range, infinite while, condition never changes, modifying a list while looping, reused loop variable),
function mistakes (wrong argument count, mutable default, missing return, no base case, missing self),
type bugs (input() used as a number, str + int, division by zero), unreachable code, unused imports/variables,
shadowed built-ins, == None, bare except, and more. It never runs the code (AST only) so it takes a few milliseconds.

## ML layer (bug-type prediction)
Goal: a model that reads code and predicts WHICH KINDS of mistakes it has: syntax / variable / loop / function / type / logic.

Pipeline
1. `python -m src.gen_data --n 9000`  - builds a labelled dataset. Clean programs (20+ hand-written templates and ~1000
   real functions from the Python stdlib) get a bug injected by one of 30 mutators; the rule-based checker labels the result
   (weak supervision). Test set = templates and stdlib MODULES never seen in training.
2. `python -m src.ml_baseline --train` - TF-IDF over name-independent code tokens + Logistic Regression (CPU, ~1 min).
   Saves models/bug_clf.joblib and results/ml_results.json.
3. `python -m src.train_codebert --out models/codebert-bugs --epochs 4` - fine-tunes CodeBERT on the same data (Colab GPU).
   Not run in the sandbox (needs a model download); if models/codebert-bugs exists the app uses it automatically.
4. `streamlit run src/app.py` -> tab "ML bug-type prediction".

Baseline results (TF-IDF + LR)
| split | micro-F1 |
|---|---|
| validation (seen templates/modules) | 0.90 |
| test: unseen templates + unseen stdlib modules | 0.66 (stdlib only 0.74, templates only 0.60) |

Honest limitations (write these in your report)
- Labels come from the checker, so the ML model imitates the rules; it is not an independent source of truth.
- Bag-of-n-grams cannot really "understand" code: it drops from 0.90 to 0.66 on unseen code. That gap is the argument for CodeBERT.
- It predicts the TYPE of bug per program, not the line. The line number always comes from the checker.
- Next steps: run CodeBERT and compare; add human-labelled student code; line-level token classification.
